matthew blackburn
atticus colwell

MS2:

Atticus: focused on main and general design of cache
Matthew: focused on functionality of load and store functions